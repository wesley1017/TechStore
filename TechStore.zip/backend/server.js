const express = require('express');
const app = express();
const port = 3000;

app.use(express.static('frontend'));

app.get('/api/products', (req, res) => {
    res.json([{ id: 1, name: "Laptop", price: 1200 }, { id: 2, name: "Phone", price: 800 }]);
});

app.listen(port, () => {
    console.log(`TechStore backend running at http://localhost:${port}`);
});
