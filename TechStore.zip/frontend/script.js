document.addEventListener("DOMContentLoaded", function() {
    document.getElementById("products").innerHTML = "<p>Loading products...</p>";
});
